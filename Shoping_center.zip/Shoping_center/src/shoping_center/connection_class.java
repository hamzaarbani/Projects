package shoping_center;


import java.sql.Connection;
import java.sql.DriverManager;


public class connection_class {

    public static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/snt", "root", "");
             
            return con;
        } catch (Exception ex) {
            return null;
        }
    }
}
