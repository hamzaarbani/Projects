
package shoping_center;

public class Shoping_center {
    public static void main(String[] args) {
     
        
        
        
        
        
        
        
        
        
        
    }
    
}
